<?php

namespace Eway\Rapid\Exception;

use RuntimeException;

/**
 * Class MassAssignmentException.
 */
class MassAssignmentException extends RuntimeException
{
}
